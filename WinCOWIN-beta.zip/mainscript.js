var timer;
var timer2;
var logouttimer;
var sound;
var otpExpireSound;

chrome.storage.local.get(null, beginScript);

async function beginScript(datas) {
    if(typeof timer2!="undefined") clearInterval(timer2);
    if(typeof timer!="undefined") clearInterval(timer);
    if(typeof logouttimer!="undefined") clearInterval(logouttimer);
    var searches=0;
    console.log(datas);
    sound = new Audio("https://mp3.fastupload.co/dl.php?file=YUhSMGNITTZMeTl0Y0RNdVptRnpkSFZ3Ykc5aFpDNWpieTlrWVhSaEx6RTJNakl3TWprNE16Y3ZiM0JsYmkweUxtMXdNdz09");
    otpExpireSound = new Audio('https://mp3.fastupload.co/dl.php?file=YUhSMGNITTZMeTl0Y0RNdVptRnpkSFZ3Ykc5aFpDNWpieTlrWVhSaEx6RTJNakV5TmpZM09USXZiM1J3Ulhod0xtMXdNdz09');
    let slots;
    let target = document.querySelector(".pin-search-btn");

    if ($("mat-label:contains('Select State')").length === 0)   $(".status-switch")[0].click()   
    await sleep(1000); 
    $("mat-select")[0].click();
    await sleep(500);
    $(".mat-option-text").each( (i, e) => { if ($(e).text().trim() === datas.state) $(e).click() });
    await sleep(2000);
    $("mat-select")[1].click();
    await sleep(500);
    $(".mat-option-text").each( (_, dEle) => { 
        if ($(dEle).text().trim()===datas.district) {
            $(dEle).click();
        }
    })
    await sleep(1000);
    $(".district-search")[0].click();

    $('.ion-text-start.book-appoinment-header.padding-0.md.hydrated')[0].innerHTML='<h5 style="background-color: midnightblue;padding: 0.1rem 1rem; color: white;">This list will not refresh as WinCOWIN is searching in background to avoid "too many request" or "logout" problem, you will be notified as slots open. To check logs press ctrl + shift + I </h5><h5 style="background-color: midnightblue;padding: 0.1rem 1rem;color: white;display: inline;"> Cowin will log you out after</h5><h5 style="background-color: midnightblue;padding: 0.1rem 1rem;color: white;display: inline;" class="timeout"></h5><h5 style="background-color: midnightblue;padding: 0.1rem 1rem;color: white;display: inline;"> Searches performed by WinCOWIN : </h5><h5 style="background-color: midnightblue;padding: 0.1rem 1rem;color: white;display: inline;" class="searches"></h5>';

    var timercount=720;
    var sec;
    logouttimer=setInterval(()=>{
        if(timercount%60<10){
            sec='0'+timercount%60;
        }else{
            sec=timercount%60;
        }
        if(typeof $('.timeout')[0] != "undefined")
            $('.timeout')[0].innerText= Math.floor(timercount/60) + " : " + sec;
        timercount=timercount-1;
        if(timercount<=0){
            otpExpireSound.play();
            clearInterval(timer);
            clearInterval(logouttimer);
        }
    }, 1000);

    backgroundSearcher();

    timer = setInterval(backgroundSearcher, (datas.refrt * 1000));

    async function backgroundSearcher(){
        searches=searches+1;
        $('.searches')[0].innerText= searches + " ";

        if (document.querySelectorAll('ion-button.login-btn').length > 0) {
            otpExpireSound.play();
            clearInterval(timer);
            clearInterval(logouttimer);
        }

        let current_datetime= addDays(new Date(), datas.skpd);
        let formatted_date = current_datetime.getDate() + "-" + (current_datetime.getMonth() + 1) + "-" + current_datetime.getFullYear();

        res=await fetch("https://cdn-api.co-vin.in/api/v2/appointment/sessions/public/calendarByDistrict?district_id="+datas.distId+"&date="+formatted_date).then(res=>res.json());

        res=res.centers;
        console.log("search results below");
        console.log(res);

        res.every(c => {
            var addr = c.name +" "+ c.address + " " + c.pincode;
            if(datas.free && c.fee_type.includes("Paid") ){
                return true;
            }
            if(datas.centers.on && !matchCenter(addr)){
                return true;
            }
            var skip=false;
            c.sessions.every(ses=>{
                if(datas.etplus && ses.min_age_limit==45){
                    return true;
                }
                if(!datas.etplus && ses.min_age_limit==18){
                    return true;
                }
                if(!matchVaccine(ses.vaccine)){
                    return true;
                }
                if( (!datas.d2 && ses.available_capacity_dose1>0) || (datas.d2 && ses.available_capacity_dose2>0) ) { 
                    console.log("open slot available at " + c.name);
                    timer2=setInterval(checkfree, datas.refrt*1000);
                    console.log(ses);
                    sound.play();
                    clearInterval(timer);
                    clearInterval(logouttimer);
                    skip=true;
                    return false;
                }
                return true;
            })
            if(skip)    return false;
            return true;
        });
    }

    async function checkfree() {
        if (document.querySelectorAll('ion-button.login-btn').length > 0) {
            otpExpireSound.play();
            clearInterval(timer);
            clearInterval(logouttimer);
        }
        console.log("checking...")
        target.click();
        await sleep(1000);
        $(".form-check").each((i, e)=>{
            if(datas.etplus && e.innerText.includes("18+"))    $(".form-check")[i].children[0].click();
            if(!datas.etplus && e.innerText.includes("45+"))    $(".form-check")[i].children[0].click();
            if(datas.vacc[0] && e.innerText.includes("Covaxin"))    $(".form-check")[i].children[0].click();
            if(datas.vacc[1] && e.innerText.includes("Covishield"))    $(".form-check")[i].children[0].click();
            if(datas.vacc[2] && e.innerText.includes("Sputnik"))    $(".form-check")[i].children[0].click();
            if(datas.free && e.innerText.includes("Free"))    $(".form-check")[i].children[0].click();
        });
        await sleep(100);
        var exit = false;
        var all=$("mat-selection-list")
        var rows = $(all).find(".slot-available-wrap");
        A: for (var i = 0; i < rows.length; i++) {
            var boxs = rows[i].children;
            if(datas.centers.on && !centerMatch(rows[i])){
                continue A;
            }
            B: for (var j = 0; j < boxs.length; j++) {
                if(j<datas.skpd)    continue B;
                for(var ii=0; ii<boxs[j].childElementCount; ii++){
                    var slot=boxs[j].children[ii];
                    if(!slot.innerText.includes("Booked") && !slot.innerText.includes("NA") && exit==false){
                        clearInterval(timer2);
                        if (datas.fwd) {
                            console.log(slot.innerText);
                            slot.click();
                            await sleep(150);
                            document.querySelectorAll('ion-button')[datas.sst].click();
                            //fillCaptcha();
                            if (datas.as) {
                                await sleep(50);
                                document.querySelector('[type="submit"]').click();
                            }
                        }
                        exit = true;
                        break B;
                    }
                }
            }
            if (exit)
                break A;
        }
    }

    function centerMatch(row) {
        var centName=row.parentElement.parentElement.children[0].innerText.toUpperCase();
        for(var ii=0; ii<datas.centers.list.length; ii++){
            if(centName.includes(datas.centers.list[ii]))
                return true;
        }
        return false;
    }

    function matchCenter(name) {
        name=name.toUpperCase();
        for(var ii=0; ii<datas.centers.list.length; ii++){
            if(name.includes(datas.centers.list[ii]))
                return true;
        }
        return false;
    }

    function matchVaccine(v) {
        v=v.toUpperCase();
        if(datas.vacc[0] && v.includes("COVAXIN"))  return true;
        if(datas.vacc[1] && v.includes("COVISHIELD"))  return true;
        if(datas.vacc[2] && v.includes("SPUTNIK"))  return true;
        return false;
    }

    function addDays(date, days) {
        var result = new Date(date);
        result.setDate(result.getDate() + days);
        return result;
    }

    function sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

}